

<?php
$mysqli = require_once "database.php";
$currentDateTime = date('Y-m-d H:i:s');
// Fetch properties for Premium
$queryPremium = "SELECT * FROM `property-info` WHERE `subscription`='premium' AND `expiry_date` >= '$currentDateTime' AND `PAcc-type` = 'Dormitory' ORDER BY RAND()";
$resultPremium = $mysqli->query($queryPremium);

$propertiesPremium = [];
if ($resultPremium) {
    while ($row = $resultPremium->fetch_assoc()) {
        $propertiesPremium[] = $row;
    }
}


$queryPremiumBH = "SELECT * FROM `property-info` WHERE `subscription`='premium' AND `expiry_date` >= '$currentDateTime' AND `PAcc-type` = 'BoardingHouse' ORDER BY RAND()";
$resultPremiumBH = $mysqli->query($queryPremiumBH);


$propertiesPremiumBH = [];
if ($resultPremiumBH) {
    while ($row = $resultPremiumBH->fetch_assoc()) {
        $propertiesPremiumBH[] = $row;
    }
}



$mysqli->close();

?>


<?php
                            // Including database connection
                            $mysqli = require "database.php";

                            // SQL to count registered owners
                            $query = "SELECT `gcash_num` FROM `admin-tb` WHERE `Admin_Id`= '1' ";
                            $Result = $mysqli->query($query);
                            if ($Result) {
                                if ($Row = $Result->fetch_assoc()) {
                                    $contactnum = $Row['gcash_num'];

                                }}
                            $mysqli->close();
                            ?>







<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css"
      
      rel="stylesheet"
    />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link rel="stylesheet" href="styles.css" />
    <title>DormNa</title>
  </head>
  <body>
    <nav>
      <div class="nav__bar">
        <div class="nav__header">
          <div class="logo nav__logo">
            <img src="assets/SLSU-LOGO.png" />
            <span>DORMNA<br /></span>
          </div>
          <div class="nav__menu__btn" id="menu-btn">
            <i class="ri-menu-line"></i>
          </div>
        </div>
        <ul class="nav__links" id="nav-links">
          <li><a href="#home">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="list.PHP">Vacancy</a></li>
          <li><a href="#feature">Feature</a></li>
          <li><a href="#menu">Menu</a></li>
          <li><a href="#news">News</a></li>
        </ul>
      </div>
    </nav>

    
    <header class="header" id="home">
    
      <div class="login-container" id="">
        <div class="login-icon"></div>
        <div class="login-text">Are you an Accomodation Owner?</div>
        <button class="login-button" onclick="location.href='login.php';">Login Here</button>
      </div>

      
      <div class="section__container header__container">
        
        <p class="section__subheader">Where distance is not a barrier to your education</p>
        <h1>FIND YOUR HOME<br />AWAY FROM HOME</h1>
   
        <button class="btn" onclick="location.href='#about';">Explore</button>
     
 </div>


<!-- <section class="dorm" id="dorm">
 
      <div class="section__container dorm__container">
        
        <div class="dorm__grid">
           
          <div class="dorm__image">
            <img src="assets/about-1.jpg" alt="dorm" />
          </div>
        
          <div class="dorm__card">
            <span><i class="ri-user-line"></i></span>
            <h4>Strong Team</h4>
            <p>
              Unlocking Hospitality Excellence And Ensures Your Perfect Stay
            </p>
          </div>
          <div class="dorm__image">
            <img src="assets/about-2.jpg" alt="dorm" />
          </div>
          <div class="dorm__card">
            <span><i class="ri-calendar-check-line"></i></span>
            <h4>Luxury Room</h4>
            <p>Experience Unrivaled Luxury at Our Exquisite Luxury Rooms</p>
          </div>
        </div>
      -->
      
    </section>
 

 

    </header>


    <?php
   $mysqli = require "database.php";

   $query = "SELECT COUNT(*) AS dorm_count FROM `property-info` WHERE `PAcc-type` = 'Dormitory'";

   $result = $mysqli->query($query);
   
   if ($result) {
       $row = $result->fetch_assoc();
       $dorm_count = $row['dorm_count'];
   } else {
       echo "Error: " . $mysqli->error;
   }
   
   
   $mysqli->close();
   
    ?>


<br><br>
    <ul class="menu__banner">
      <li>
        <span><i class="ri-community-line"></i></span>
        <h4><?php echo $dorm_count?>+</h4>
        <p>Dormitories Listed</p>
      </li>
      <li>

      <?php
   $mysqli = require "database.php";

   $query = "SELECT COUNT(*) AS bh_count FROM `property-info` WHERE `PAcc-type` = 'BoardingHouse'";

   $result = $mysqli->query($query);
   
   if ($result) {
       $row = $result->fetch_assoc();
       $bh_count = $row['bh_count'];
   } else {
       echo "Error: " . $mysqli->error;
   }
   
   $mysqli->close();
   
    ?>

        <span><i class="ri-home-2-line"></i></span>
        <h4><?php echo $dorm_count?>+</h4>
        <p>Boarding Houses Listed</p>
      </li>
      <li>
        <span><i class="ri-map-pin-line"></i></span>
        <h4>Lucban</h4>
        <p>Exclusive Location</p>
      </li>

      <?php
   $mysqli = require "database.php";

   $query = "SELECT SUM(`PNum-slot-avail`) AS slots_count FROM `property-info`";

   $result = $mysqli->query($query);

   if ($result) {
       $row = $result->fetch_assoc();
       $totalAvailableSlots = $row['slots_count'];
    
   } else {
       echo "Error: " . $mysqli->error;
   }
   
   
   $mysqli->close();
   
    ?>

      <li>
        <span><i class="ri-group-line"></i></span>
        <h4><?php  echo $totalAvailableSlots?>+</h4>
        <p>Available Slots</p>
      </li>
    </ul>
    



    

    <section class="about" id="about">
      <div class="section__container about__container">
        <div class="about__grid">
          <div class="about__image">
            <img src="assets/dormitoryIMG.jpg" alt="about" />
          </div>
          <div class="about__card">
            <div class="iconDorm">
              <img src="assets/dormitory.png" alt="about" />
              </div>
            <h4>Dormitory</h4>
            <p>
              Discover the convenience of dormitory living, where students come together to study, socialize, and thrive
            </p>
          </div>
          <div class="about__image">
            <img src="assets/boardinghouse.jpg  " alt="about" />
          </div>
          <div class="about__card">
            <div class="iconBH">
              <img src="assets/boarding house.png" alt="about" />
              </div>
            <h4>Boarding House</h4>
            <p>Experience the comfort and affordability of a boarding house, offering furnished rooms and shared amenities for a cozy home away from home</p>
          </div>
        </div>
        <div class="about__content">
          <p class="section__subheader">ABOUT US</p>
          <h2 class="section__header">Discover <br> Our Website</h2>
          <p class="section__description">
            Welcome to DormNa! We're all about helping students like you find comfy and affordable dorms or boarding houses. No matter where you're studying, DormNa has got you covered. Find your home away from home!
          </p>
          <button class="btn" onclick="location.href='list.PHP';">Find Now</button>
        </div>
      </div>
    </section>

    <section class="room__container" id="room">
      <div class="Acomodation__header">
        <div>
          <p class="section__subheader">Dormitories</p>
          <h2 class="section__header">Suggested Dormitories</h2>
        </div>
        
      </div>


    






      <section class="properties">
    <div class="container" id="premium_dorm">
        <div class="properties-grid-featured" id="propertiesGrid">
            <?php
            $max_display = 8; // Set the maximum number of cards to display
            $count = 0; // Initialize counter
            foreach ($propertiesPremium as $index => $property):
                if ($count >= $max_display) break; // Stop the loop after displaying two cards
                ?>
                <div class="property-card-featured"
                     data-property-id="<?= htmlspecialchars($property['PID']) ?>"
                     data-property-name="<?= htmlspecialchars($property['Pname']) ?>"
                     data-property-street="<?= htmlspecialchars($property['PStreet']) ?>"
                     data-property-brgy="<?= htmlspecialchars($property['PBrgy']) ?>"
                     data-property-type="<?= htmlspecialchars($property['PAcc-type']) ?>"
                     data-property-price="<?= htmlspecialchars($property['Pprice']) ?>"
                     data-property-fb="<?= htmlspecialchars($property['PFBname']) ?>"
                     data-property-contact-name="<?= htmlspecialchars($property['Pcontact-name']) ?>"
                     data-property-contact-num="<?= htmlspecialchars($property['Pcontact-num']) ?>"
                     data-property-slots="<?= htmlspecialchars($property['PNum-slot-avail']) ?>"
                     data-property-image="img/<?= htmlspecialchars($property['Pimage']) ?>"
                     data-property-gender="<?= htmlspecialchars($property['PGender']) ?>"
                     data-property-dscrption="<?= htmlspecialchars($property['PDscrpt']) ?>"
                        data-property-wifi="<?= htmlspecialchars($property['PWifi']) ?>"
                        data-property-water="<?= htmlspecialchars($property['PWater']) ?>"
                        data-property-electric="<?= htmlspecialchars($property['PElectric']) ?>"
                        data-property-accredited="<?= htmlspecialchars($property['accredited']) ?>"
                     data-page="<?= $currentPage ?>">
                    <div class="image-container-premium">
                    <?php
                              $slot = htmlspecialchars($property['PNum-slot-avail' ]);
                              if ($slot > 0 ) {
                                $slot =  "<img src=assets/premium.png />";

                              } elseif ($slot <= 0) {
                                $slot = "<img src= assets/occupied.png />";
                              }
                              ?>
        
        <span class="iconPremium"><?php echo $slot?></span>

                        <img src="img/<?= htmlspecialchars($property['Pimage']) ?>" alt="Property Image" class="property-image">
                    </div>
                    <div class="property-details-initial">
                    <h2 class="property-address"><?= htmlspecialchars($property['Pname']) ?></h2>
                    <p class="property-address"><i class="fas fa-map-marker-alt"></i>&nbsp <?= htmlspecialchars($property['PBrgy']) ?>, <?= htmlspecialchars($property['PStreet']) ?></p>

                    <p class="property-type"><i class="fas fa-home"></i>&nbsp <?= htmlspecialchars($property['PAcc-type']) ?></p>
                    <p class="property-price"><i class="fas fa-peso-sign"></i>&nbsp <?= htmlspecialchars($property['Pprice']) ?>/Month  
                                  &nbsp&nbsp&nbsp&nbsp&nbsp
                        <?php
                        if (htmlspecialchars($property['PWifi']) == 'Yes') {
                            echo '<i class="fas fa-wifi"></i> Free WiFi'; // Displays icon with "Free WiFi"
                        } else {
                            // You can customize what to show when there's no WiFi
                        }
                        ?>
                   </p>

                  
                  </p><br>
                  <div class="property-icons" >
                        <p class="property-slots"><i class="fas fa-bed">&nbsp </i> <?= htmlspecialchars($property['PNum-slot-avail']) ?>&nbsp&nbsp&nbsp&nbsp&nbsp
                        <?php 
                              $gender = htmlspecialchars($property['PGender']);
                              if ($gender == 'Male') {
                                $gender =  "Male only";
                                echo '<i class="fas fa-mars"></i> ' . $gender;
                              } elseif ($gender == 'Female') {
                                $gender =  "Female only";
                                echo '<i class="fas fa-venus"></i> ' . $gender;
                              } elseif ($gender == 'Mixed') {
                                $gender =  "Mixed Gender";
                                echo '<i class="fas fa-mars"></i><i class="fas fa-venus"></i> ' . $gender;
                              } 
                              ?>
                       </p>    
                    </div>
                    </div>
                </div>
                <?php
                $count++; // Increment counter after each displayed property
            endforeach;
            ?>
        </div>
    </div>
</section>



     
      <div class="section__nav">
        <button class="btn" onclick="location.href='list.php';">Show more</button>
      </div>

    </section>


    <section class="room__container" id="room">

      <div class="Acomodation__header">
      <div>
        <p class="section__subheader">Boarding House</p>
        <h2 class="section__header">Suggested Boarding Houses</h2>
      </div>
      </div>
      <section class="properties">
    <div class="container" id="premium_BH">
        <div class="properties-grid-featured" id="propertiesGrid">
            <?php
            $max_display = 8; // Set the maximum number of cards to display
            $count = 0; // Initialize counter
            foreach ($propertiesPremiumBH as $index => $property):
                if ($count >= $max_display) break; // Stop the loop after displaying two cards
                ?>
                <div class="property-card-featured-BH"
                     data-property-id="<?= htmlspecialchars($property['PID']) ?>"
                     data-property-name="<?= htmlspecialchars($property['Pname']) ?>"
                     data-property-street="<?= htmlspecialchars($property['PStreet']) ?>"
                     data-property-brgy="<?= htmlspecialchars($property['PBrgy']) ?>"
                     data-property-type="<?= htmlspecialchars($property['PAcc-type']) ?>"
                     data-property-price="<?= htmlspecialchars($property['Pprice']) ?>"
                     data-property-fb="<?= htmlspecialchars($property['PFBname']) ?>"
                     data-property-contact-name="<?= htmlspecialchars($property['Pcontact-name']) ?>"
                     data-property-contact-num="<?= htmlspecialchars($property['Pcontact-num']) ?>"
                     data-property-slots="<?= htmlspecialchars($property['PNum-slot-avail']) ?>"
                     data-property-image="img/<?= htmlspecialchars($property['Pimage']) ?>"
                     data-property-gender="<?= htmlspecialchars($property['PGender']) ?>"
                     data-property-dscrption="<?= htmlspecialchars($property['PDscrpt']) ?>"
                        data-property-wifi="<?= htmlspecialchars($property['PWifi']) ?>"
                        data-property-water="<?= htmlspecialchars($property['PWater']) ?>"
                        data-property-electric="<?= htmlspecialchars($property['PElectric']) ?>"
                        data-property-accredited="<?= htmlspecialchars($property['accredited']) ?>"
                     data-page="<?= $currentPage ?>">
                    <div class="image-container-premium">

                    <?php
                              $slot = htmlspecialchars($property['PNum-slot-avail' ]);
                              if ($slot > 0 ) {
                                $slot =  "<img src=assets/premium.png />";

                              } elseif ($slot <= 0) {
                                $slot = "<img src= assets/occupied.png />";
                              }
                              ?>
   
        <span class="iconPremium"><?php echo $slot?></span>
                    
                        <img src="img/<?= htmlspecialchars($property['Pimage']) ?>" alt="Property Image" class="property-image">
                    </div>
                    <div class="property-details-initial">
                    <h2 class="property-address"><?= htmlspecialchars($property['Pname']) ?></h2>
                    <p class="property-address"><i class="fas fa-map-marker-alt"></i>&nbsp <?= htmlspecialchars($property['PBrgy']) ?>, <?= htmlspecialchars($property['PStreet']) ?></p>

                    <p class="property-type"><i class="fas fa-home"></i>&nbsp <?= htmlspecialchars($property['PAcc-type']) ?></p>
                    <p class="property-price"><i class="fas fa-peso-sign"></i>&nbsp <?= htmlspecialchars($property['Pprice']) ?>/Month  
                                  &nbsp&nbsp&nbsp&nbsp&nbsp
                        <?php
                        if (htmlspecialchars($property['PWifi']) == 'Yes') {
                            echo '<i class="fas fa-wifi"></i> Free WiFi'; // Displays icon with "Free WiFi"
                        } else {
                            // You can customize what to show when there's no WiFi
                        }
                        ?>
                   </p>

                  
                  </p><br>
                  <div class="property-icons" >
                        <p class="property-slots"><i class="fas fa-bed">&nbsp </i> <?= htmlspecialchars($property['PNum-slot-avail']) ?>&nbsp&nbsp&nbsp&nbsp&nbsp
                        <?php 
                              $gender = htmlspecialchars($property['PGender']);
                              if ($gender == 'Male') {
                                $gender =  "Male only";
                                echo '<i class="fas fa-mars"></i> ' . $gender;
                              } elseif ($gender == 'Female') {
                                $gender =  "Female only";
                                echo '<i class="fas fa-venus"></i> ' . $gender;
                              } elseif ($gender == 'Mixed') {
                                $gender =  "Mixed Gender";
                                echo '<i class="fas fa-mars"></i><i class="fas fa-venus"></i> ' . $gender;
                              } 
                              ?>
                       </p>    
                    </div>
                    </div>
                </div>
                <?php
                $count++; // Increment counter after each displayed property
            endforeach;
            ?>
        </div>
    </div>
</section>




<div class="section__nav">
        <button class="btn" onclick="location.href='list.php';">Show more</button>
      </div>

      <div id="propertyDetails" class="property-details-container"></div>
    </section>


    <!--
    <section class="intro">
      <div class="section__container intro__container">
        <div class="intro__cotent">
          <p class="section__subheader">INTRO VIDEO</p>
          <h2 class="section__header">Meet With Our Luxury Place</h2>
          <p class="section__description">
            Whether you're seeking a cozy and exclusive hideaway or an immersive
            journey beneath the surface, Hotel Miranda promises to be an
            unforgettable stay, where the depths of comfort and excitement await
            your arrival.
          </p>
          <button class="btn">Book Now</button>
        </div>
        <div class="intro__video">
          <video src="assets/luxury.mp4" autoplay muted loop></video>
        </div>
      </div>
    </section>
          -->
    <section class="section__container feature__container" id="feature">
      <p class="section__subheader">FEATURES</p>
      <h2 class="section__header">DormNa Core Features</h2>
      <div class="feature__grid">
        <div class="feature__card">
          <span><i class="ri-search-line"></i></span>
          <h4>Search</h4>
          <p>
          Students can easily search for the name or location of preferred dormitories and boarding houses.
          </p>
        </div>
        <div class="feature__card">
          <span><i class="ri-filter-3-line"></i></span>
          <h4>Search Filters</h4>
          <p>
          Use search filters to refine search results based on specific criteria such as price range, amenities, utilities included in the rent, and gender-specific accommodation.
          </p>
        </div>
        <div class="feature__card">
          <span><i class="ri-building-line"></i></span>
          <h4>Exclusively for SLSU Students</h4>
          <p>
            Designed with SLSU students in mind, offering accommodations that meet the needs and preferences of students studying in Lucban.
          </p>
        </div>
        <div class="feature__card">
          <span><i class="ri-vip-crown-line"></i></span>
          <h4>Property Subscription Model</h4>
          <p>
            Accommodation owners can showcase their properties through a subscription model, gaining access to a targeted audience of students.
          </p>
        </div>
        <div class="feature__card">
          <span><i class="ri-map-pin-2-line"></i></span>
          <h4>Lucban Location Focus</h4>
          <p>
            All listings are located in Lucban, ensuring that students find convenient accommodations close to their campus and local amenities.
          </p>
        </div>
        <div class="feature__card">
          <span><i class="ri-information-line"></i></span>
          <h4>Campus Kiosk Integration</h4>
          <p>
            A unique feature offering campus kiosks where students can access DormNa directly, making it easier to find accommodations.
          </p>
        </div>
      </div>
    </section>
    
<!--
    <section class="menu" id="menu">
      <div class="section__container menu__container">
        <div class="menu__header">
          <div>
            <p class="section__subheader">MENU</p>
            <h2 class="section__header">Our Food Menu</h2>
          </div>
          <div class="section__nav">
            <span><i class="ri-arrow-left-line"></i></span>
            <span><i class="ri-arrow-right-line"></i></span>
          </div>
        </div>
        <ul class="menu__items">
          <li>
            <img src="assets/menu-1.jpg" alt="menu" />
            <div class="menu__details">
              <h4>Fggs & Bacon</h4>
              <p>
                It is a culinary innovation that puts a unique spin on the
                beloved breakfast combination.
              </p>
            </div>
          </li>
          <li>
            <img src="assets/menu-2.jpg" alt="menu" />
            <div class="menu__details">
              <h4>Tea or Coffee</h4>
              <p>
                A classic choice for your daily dose of comfort and calmness.
              </p>
            </div>
          </li>
          <li>
            <img src="assets/menu-3.jpg" alt="menu" />
            <div class="menu__details">
              <h4>Chia Oatmeal</h4>
              <p>
                Our Chia Oatmeal is a wholesome nutrient-packed breakfast
                delight.
              </p>
            </div>
          </li>
          <li>
            <img src="assets/menu-4.jpg" alt="menu" />
            <div class="menu__details">
              <h4>Fruit Parfait</h4>
              <p>
                Our Fruit Parfait is a delightful culinary masterpiece of
                freshness and flavor.
              </p>
            </div>
          </li>
          <li>
            <img src="assets/menu-5.jpg" alt="menu" />
            <div class="menu__details">
              <h4>Marmalade Selection</h4>
              <p>
                Our Marmalade Selection is a delectable medley of vibrant,
                handcrafted citrus preserves.
              </p>
            </div>
          </li>
          <li>
            <img src="assets/menu-6.jpg" alt="menu" />
            <div class="menu__details">
              <h4>Cheese Plate</h4>
              <p>
                Our cheese plate is a masterpiece that celebrates rich and
                diverse world of cheeses.
              </p>
            </div>
          </li>
        </ul>
        <div class="menu__images">
          <img src="assets/menu-7.jpg" alt="menu" />
          <img src="assets/menu-8.jpg" alt="menu" />
          <img src="assets/menu-9.jpg" alt="menu" />
        </div>

      -->
      
      
<!--
    <section class="section__container news__container" id="news">
      <div class="news__header">
        <div>
          <p class="section__subheader">BLOG</p>
          <h2 class="section__header">News Feeds</h2>
        </div>
        <div class="section__nav">
          <span><i class="ri-arrow-left-line"></i></span>
          <span><i class="ri-arrow-right-line"></i></span>
        </div>
      </div>
      <div class="news__grid">
        <div class="news__card">
          <img src="assets/news-1.jpg" alt="news" />
          <div class="news__card__title">
            <p>25th March 2022</p>
            <p>By Emily</p>
          </div>
          <h4>Exploring Local Culinary Gems: A Foodie's Guide.</h4>
          <p>
            Join Emily as she takes you on a gastronomic adventure through the
            neighborhood surrounding our hotel.
          </p>
        </div>
        <div class="news__card">
          <img src="assets/news-2.jpg" alt="news" />
          <div class="news__card__title">
            <p>15th June 2022</p>
            <p>By David</p>
          </div>
          <h4>Balancing Mind, Body, and Soul at Our Hotel.</h4>
          <p>
            Discover holistic spa treatments, fitness facilities, and
            mindfulness practices that will leave you feeling refreshed.
          </p>
        </div>
        <div class="news__card">
          <img src="assets/news-3.jpg" alt="news" />
          <div class="news__card__title">
            <p>08th August 2022</p>
            <p>By Sarah</p>
          </div>
          <h4>Exploring Outdoor Activities Near Our Hotel.</h4>
          <p>
            From hiking and biking trails to water sports and wildlife
            encounters, she highlights ways to experience nature's wonders.
          </p>
        </div>
      </div>
    </section>
-->

<br><br><br><br>
    <footer class="footer">
      <div class="section__container footer__container">
        <div class="footer__col">
          <div class="logo footer__logo">
            <div>D</div>
            <span>DormNa</span>
          </div>
          <p class="section__description">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil,
            laudantium unde. Doloremque eaque debitis laborum labore voluptates
            iste molestiae consectetur.
          </p>
          <ul class="footer__socials">
            <li>
              <a href="#"><i class="ri-youtube-fill"></i></a>
            </li>
            <li>
              <a href="#"><i class="ri-instagram-line"></i></a>
            </li>
            <li>
              <a href="#"><i class="ri-facebook-fill"></i></a>
            </li>
            <li>
              <a href="#"><i class="ri-linkedin-fill"></i></a>
            </li>
          </ul>
        </div>
        <div class="footer__col">
          <h4>Services</h4>
          <div class="footer__links">
            <li><a href="#">Dormitory List</a></li>
            <li><a href="#">Boarding House List</a></li>
            <li><a href="#">Search with Filters</a></li>
            <li><a href="#">Suggested Acomodation</a></li>
            <li><a href="#">Upload Slots For owners</a></li>
            <li><a href="#">Customer Support</a></li>
          </div>
        </div>
        <div class="footer__col">
          <h4>Contact Us</h4>
          <div class="footer__links">
            <li>
              <span><i class="ri-phone-fill"></i></span>
              <div>


  
                <h5>Phone Number</h5>
                <p><?php echo $contactnum  ?></p>
              </div>
            </li>
            <li>
              <span><i class="ri-record-mail-line"></i></span>
              <div>
                <h5>Email</h5>
                <p>DormNa@gmail.com</p>
              </div>
            </li>
            <li>
              <span><i class="ri-map-pin-2-fill"></i></span>
              <div>
                <h5>Location</h5>
                <p>Lucban Quezon, Philippines</p>
              </div>
            </li>
          </div>
        </div>
      </div>
      <div class="footer__bar">
        Copyright © 2024 DormNa. All rights reserved.
      </div>
    </footer>

    <script src="https://unpkg.com/scrollreveal"></script>
    <script src="main.js"></script>



    <script > 
document.addEventListener('DOMContentLoaded', function() {
  const propertyCards = document.querySelectorAll('.property-card-featured');
  const detailsContainer = document.getElementById('propertyDetails');

  propertyCards.forEach(card => {
    card.addEventListener('click', function() {
      const propertyId = this.dataset.propertyId;
      const propertyName = this.dataset.propertyName;
      const propertyAddress = `${this.dataset.propertyStreet}, ${this.dataset.propertyBrgy}`;
      const propertyType = this.dataset.propertyType;
      const propertyPrice = this.dataset.propertyPrice;
      const propertyImage = this.dataset.propertyImage;
      const propertyFb = this.dataset.propertyFb;
      const propertyContactName = this.dataset.propertyContactName;
      const propertyContactNum = this.dataset.propertyContactNum;
      const propertySlots = this.dataset.propertySlots;
      const propertyGender = this.dataset.propertyGender;
      const propertyDescription = this.dataset.propertyDscrption;
      const propertyWifi = this.dataset.propertyWifi;
      const propertyWater = this.dataset.propertyWater;
      const propertyElectric = this.dataset.propertyElectric;
      const propertyAccredited = this.dataset.propertyAccredited;


      // Build the details HTML
      const propertyDetails = `
      <div class="property-details">
          <img src="${propertyImage}" alt="Property Image" class="property-image-full">
          <div class="property-details_2">
          <div class="property-info">
         
            <h2>Name: ${propertyName}</h2>
            <p>Accredited by SLSU: <i class="${propertyAccredited === "yes" ? 'fas fa-check-circle' : 'fas fa-times-circle'}" style="color: ${propertyAccredited === "yes" ? 'green' : 'red'};"></i></p>
            <p>Address: ${propertyAddress}</p>
            <p>Type: ${propertyType}</p>
            <p>Price: ₱${propertyPrice}/Month</p>
            <p>Facebook: ${propertyFb}</p>
            <p>Contact: ${propertyContactName}, ${propertyContactNum}</p>
            <p>Slots Available: ${propertySlots}</p>
            <p>Gender: ${propertyGender}</p>
            <p>Description: ${propertyDescription}</p>
            <h4>Utilities and Amenities Included:</h4>
            <p>
              Wifi: <i class="${propertyWifi === "Yes" ? 'fas fa-check-circle' : 'fas fa-times-circle'}" style="color: ${propertyWifi === "Yes" ? 'green' : 'red'};"></i>
              Water: <i class="${propertyWater === "Yes" ? 'fas fa-check-circle' : 'fas fa-times-circle'}" style="color: ${propertyWater === "Yes" ? 'green' : 'red'};"></i>
              Electric: <i class="${propertyElectric === "Yes" ? 'fas fa-check-circle' : 'fas fa-times-circle'}" style="color: ${propertyElectric === "Yes" ? 'green' : 'red'};"></i>
            </p>
            <button class="field_btn" name="submit" onclick="location.href='#premium_dorm';">Back</button>
          </div>
          </div>
        </div>`;


      detailsContainer.innerHTML = propertyDetails;
      detailsContainer.style.display = 'block';
      detailsContainer.scrollIntoView({ behavior: 'smooth' });
    });
  });
});




</script>


<script > 
document.addEventListener('DOMContentLoaded', function() {
  const propertyCards = document.querySelectorAll('.property-card-featured-BH');
  const detailsContainer = document.getElementById('propertyDetails');

  propertyCards.forEach(card => {
    card.addEventListener('click', function() {
      const propertyId = this.dataset.propertyId;
      const propertyName = this.dataset.propertyName;
      const propertyAddress = `${this.dataset.propertyStreet}, ${this.dataset.propertyBrgy}`;
      const propertyType = this.dataset.propertyType;
      const propertyPrice = this.dataset.propertyPrice;
      const propertyImage = this.dataset.propertyImage;
      const propertyFb = this.dataset.propertyFb;
      const propertyContactName = this.dataset.propertyContactName;
      const propertyContactNum = this.dataset.propertyContactNum;
      const propertySlots = this.dataset.propertySlots;
      const propertyGender = this.dataset.propertyGender;
      const propertyDescription = this.dataset.propertyDscrption;
      const propertyWifi = this.dataset.propertyWifi;
      const propertyWater = this.dataset.propertyWater;
      const propertyElectric = this.dataset.propertyElectric;
      const propertyAccredited = this.dataset.propertyAccredited;


      // Build the details HTML
      const propertyDetails = `
      <div class="property-details">
          <img src="${propertyImage}" alt="Property Image" class="property-image-full">
          <div class="property-details_2">
          <div class="property-info">
         
            <h2>Name: ${propertyName}</h2>
            <p>Accredited by SLSU: <i class="${propertyAccredited === "yes" ? 'fas fa-check-circle' : 'fas fa-times-circle'}" style="color: ${propertyAccredited === "yes" ? 'green' : 'red'};"></i></p>
            <p>Address: ${propertyAddress}</p>
            <p>Type: ${propertyType}</p>
            <p>Price: ₱${propertyPrice}/Month</p>
            <p>Facebook: ${propertyFb}</p>
            <p>Contact: ${propertyContactName}, ${propertyContactNum}</p>
            <p>Slots Available: ${propertySlots}</p>
            <p>Gender: ${propertyGender}</p>
            <p>Description: ${propertyDescription}</p>
            <h4>Utilities and Amenities Included:</h4>
            <p>
              Wifi: <i class="${propertyWifi === "Yes" ? 'fas fa-check-circle' : 'fas fa-times-circle'}" style="color: ${propertyWifi === "Yes" ? 'green' : 'red'};"></i>
              Water: <i class="${propertyWater === "Yes" ? 'fas fa-check-circle' : 'fas fa-times-circle'}" style="color: ${propertyWater === "Yes" ? 'green' : 'red'};"></i>
              Electric: <i class="${propertyElectric === "Yes" ? 'fas fa-check-circle' : 'fas fa-times-circle'}" style="color: ${propertyElectric === "Yes" ? 'green' : 'red'};"></i>
            </p>
            <button class="field_btn" name="submit" onclick="location.href='#premium_BH';">Back</button>
          </div>
          </div>
        </div>`;

      detailsContainer.innerHTML = propertyDetails;
      detailsContainer.style.display = 'block';
      detailsContainer.scrollIntoView({ behavior: 'smooth' });
    });
  });
});




</script>

  </body>
</html>

