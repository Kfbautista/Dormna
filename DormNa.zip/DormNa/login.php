
<?php
session_start();
if (isset($_SESSION["user"])) {
   header("Location: dash-owner.php");
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Form</title>
  <link rel="stylesheet" href="styles.css">



  <style>
    /* Your CSS goes here */
  </style>
</head>
<body>




  <div class="bod">

    <div class="wrapper">
      <div class="title-text">
        <div class="title login">Login Form</div>
        <div class="title signup">Signup Form</div>
      </div>
      <div class="form-container-login">
        <div class="slide-controls">
          <input type="radio" name="slide" id="login" checked>
          <input type="radio" name="slide" id="signup">
          <label for="login" class="slide login">Login</label>
          <label for="signup" class="slide signup">Signup</label>
          <div class="slider-tab"></div>
        </div>
        <div class="form-inner">


          <form  class="login" action="login.php" method="post">
            <div class="field">
              <input type="text" name="email" placeholder="Email Address" required>
            </div>
            <div class="field">
              <input type="password" name="password" placeholder="Password" required>
            </div>



        <?php
        if (isset($_POST["login"])) {
           $email = $_POST["email"];
           $password = $_POST["password"];

         

            require_once "database.php";
    
            $sql = "SELECT * FROM user_account WHERE username = '$email'";
            $result = mysqli_query($conn, $sql);
            $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
            if ($user) {
                if (password_verify($password, $user["password"])) {
                    session_start();
                    $_SESSION["user"] = "yes";
                    $_SESSION["userID"] = $user['UID'];
                    header("Location: dash-owner.php");
                    die();
                }else{
                   echo "<div style='background-color: #f44336; color: white; padding: 14px 20px; margin: 10px 0; border: none; cursor: pointer; width: 100%; text-align: center;'>Password does not match</div>";

                }
            }else{
            
              echo "<div style='background-color: #f44336; color: white; padding: 14px 20px; margin: 10px 0; border: none; cursor: pointer; width: 100%; text-align: center;'>Email does not match</div>";

            }
        }
        ?>

   

            <div class="pass-link"><a href="forgot-password.php">Forgot password?</a></div>
            <button class="field_btn" name="login">Login</button>
            <div class="signup-link">Not a member? <a href="#">Signup now</a></div>
          </form>




          <form action="login.php#signup" method="post" class="signup" id="signup">
            <div class="field">
              <input type="text" name="email" placeholder="Email Address" required>
            </div>
            <div class="field">
              <input type="password" name="password" placeholder="Password" required>
            </div>
            <div class="field">
              <input type="password" name="repeat_password" placeholder="Confirm password" required>
         </div>

         
<?php
  if (isset($_POST["submit"])) {
  $email = $_POST["email"];
  $password = $_POST["password"];
  $passwordRepeat = $_POST["repeat_password"];
  $passwordHash = password_hash($password, PASSWORD_DEFAULT);
  $errors = array();
  $mysqli = require_once "database.php";

  // Checking if the email is already registered
  $query = "SELECT * FROM `user_account` WHERE `username` = ?";
  $stmt = $mysqli->prepare($query);
  $stmt->bind_param("s", $email);
  $stmt->execute();
  $result = $stmt->get_result();
  $rowCount = $result->num_rows;

  if ($rowCount > 0) {
      echo "<div style='background-color: #f44336; color: white; padding: 14px 20px; margin: 10px 0; border: none; cursor: pointer; width: 100%; text-align: center;'>Email already exists!</div>";
  } else {
      if (empty($email) || empty($password) || empty($passwordRepeat)) {
          array_push($errors, "All fields are required");
      } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          echo "<div style='background-color: #f44336; color: white; padding: 14px 20px; margin: 10px 0; border: none; cursor: pointer; width: 100%; text-align: center;'>Email is not valid</div>";
      } else if (strlen($password) < 8) {
          echo "<div style='background-color: #f44336; color: white; padding: 14px 20px; margin: 10px 0; border: none; cursor: pointer; width: 100%; text-align: center;'>Password must be at least 8 characters long</div>";
      } else if ($password !== $passwordRepeat) {
          echo "<div style='background-color: #f44336; color: white; padding: 14px 20px; margin: 10px 0; border: none; cursor: pointer; width: 100%; text-align: center;'>Password does not match</div>";
      } else {
          $sql = "INSERT INTO `user_account` (`username`, `password`) VALUES (?, ?)";
          $stmt = $mysqli->prepare($sql);
          if ($stmt) {
              $stmt->bind_param("ss", $email, $passwordHash);
              $stmt->execute();
              echo "<div class='alert alert-success' style='background-color: #006400; color: white; padding: 14px 20px; margin: 10px 0; border: none; cursor: pointer; width: 100%; text-align: center;'>You are registered successfully.</div>";
          } else {
              die("Something went wrong with preparing the statement");
          }
      }
  }
  $stmt->close();
  $mysqli->close();
}
?>



<div class="signUp_btn">
            <button class="field_btn" name="submit" >Signup</button>
      </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  
  <script>


   // JavaScript to handle form slide

  // JavaScript to handle form slide
  const loginText = document.querySelector(".title-text .login");
  const loginForm = document.querySelector("form.login");
  const loginBtn = document.querySelector("label.login");
  const signupBtn = document.querySelector("label.signup");
  const signupLink = document.querySelector("form .signup-link a");
  const signUpButton = document.querySelector('.signUp_btn button');

  // Check for hash in the URL on load to keep the form state
  window.addEventListener('load', () => {
    if (window.location.hash === '#signup') {
      showSignupForm();
    }
  });

  // Show signup form without changing the page state
  function showSignupForm() {
    loginForm.style.marginLeft = "-50%";
    loginText.style.marginLeft = "-50%";
  }

  // Set up click event for signup button
  signupBtn.onclick = () => {
    window.location.hash = 'signup';
    showSignupForm();
  };

  // Set up click event for login button
  loginBtn.onclick = () => {
    window.location.hash = 'login';
    loginForm.style.marginLeft = "0%";
    loginText.style.marginLeft = "0%";
  };

  // Set up click event for the link to the signup form
  signupLink.onclick = () => {
    signupBtn.click();
    return false;
  };

  // Set up the form submission using AJAX
  document.querySelector('.signup').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent traditional form submission

    let formData = new FormData(this);

    fetch('login.php', {
      method: 'POST',
      body: formData
    })
    .then(response => response.text())
    .then(data => {
      console.log(data);
      // Optionally do something with the response
    })
    .catch(error => {
      console.error('Error:', error);
    });

    // Keep the signup form visible
    showSignupForm();
  });

  // Ensure that the signup form stays visible after clicking the signup button
  signUpButton.addEventListener('click', function() {
    window.location.hash = 'signup';
    showSignupForm();
  });

</script>


  </script>


<script src="https://unpkg.com/scrollreveal"></script>
<script src="main.js"></script>
</body>
</html>
